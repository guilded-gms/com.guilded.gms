<?php
namespace app\page;
use wcf\page\AbstractPage;

class IndexPage extends AbstractPage {

}
